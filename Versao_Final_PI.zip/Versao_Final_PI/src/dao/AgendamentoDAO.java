package dao;

import conector.DbConector;
import entidades.Agendamento;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class AgendamentoDAO {
    
     public static List<Agendamento> Historico() throws SQLException {

        PreparedStatement ps;
        ResultSet res;

        String select = "select * from VwAgendamentosInativos vw order by vw.DataAtendimento asc";

        ps = DbConector.CriaConexao().prepareStatement(select);
        res = ps.executeQuery();

        List<Agendamento> listaAgendamentoInativo = new ArrayList<>();
        
        
        while (res.next()) {
            Agendamento a = new Agendamento();
            a.setIdAgendamento(res.getInt("IdAgendamento"));
            a.setIdCliente(res.getInt("IdCliente"));
            a.setNomeCliente(res.getString("NomeCliente"));
            a.setIdServico(res.getInt("IdServico"));
            a.setNomeServico(res.getString("NomeServico"));
            a.setTipoAtendimento(res.getString("TipoAtendimento"));
            a.setAtendente(res.getString("Atendente"));
            a.setDataAtendimento(res.getString("DataAtendimento"));
            a.setPrecoAtendimento(res.getDouble("PrecoAtendimento"));

            listaAgendamentoInativo.add(a);
        }

        return listaAgendamentoInativo;
    }

    public static List<Agendamento> Agendamento() throws SQLException {

        PreparedStatement ps;
        ResultSet Resultado;

        String select = "select * from VwAgendamentosAtivos order by DataAtendimento asc";

        ps = DbConector.CriaConexao().prepareStatement(select);
        Resultado = ps.executeQuery();

        List<Agendamento> listaAgendamento = new ArrayList<>();

        Agendamento a = new Agendamento();

        while (Resultado.next()) {
            Agendamento Agendamento = new Agendamento();
            Agendamento.setIdAgendamento(Resultado.getInt("IdAgendamento"));
            Agendamento.setIdCliente(Resultado.getInt("IdCliente"));
            Agendamento.setNomeCliente(Resultado.getString("NomeCliente"));
            Agendamento.setIdServico(Resultado.getInt("IdServico"));
            Agendamento.setNomeServico(Resultado.getString("NomeServico"));
            Agendamento.setTipoAtendimento(Resultado.getString("TipoAtendimento"));
            Agendamento.setAtendente(Resultado.getString("Atendente"));
            Agendamento.setDataAtendimento(Resultado.getString("DataAtendimento"));
            Agendamento.setPrecoAtendimento(Resultado.getDouble("PrecoAtendimento"));

            listaAgendamento.add(Agendamento);
        }

        return listaAgendamento;
    }

    public static void Insercao(Agendamento Agendamento) throws SQLException {

        String Insert = "insert into Agendamento(IdCliente, NomeCliente, IdServico, NomeServico, TipoAtendimento, Atendente, DataAtendimento, PrecoAtendimento) VALUES(?, ?, ?, ?, ?, ?, ?, ?)";
        PreparedStatement ps;

        ClienteDAO.SelectCliente(Agendamento);
        ServicoDAO.SelectServico(Agendamento);

        ps = DbConector.CriaConexao().prepareStatement(Insert);
        ps.setInt(1, Agendamento.getIdCliente());
        ps.setString(2, Agendamento.getNomeCliente());
        ps.setInt(3, Agendamento.getIdServico());
        ps.setString(4, Agendamento.getNomeServico());
        ps.setString(5, Agendamento.getTipoAtendimento());
        ps.setString(6, Agendamento.getAtendente());
        ps.setString(7, Agendamento.dataAtendimento);
        ps.setDouble(8, Agendamento.getPrecoAtendimento());
        ps.execute();

    }

    public static void AtualizaAgendamento(Agendamento Agendamento) throws SQLException {

        String atualizacao = "call EditaAgendamento(?,?,?)";
        PreparedStatement ps;

        ps = DbConector.CriaConexao().prepareStatement(atualizacao);
        ps.setInt(1, Agendamento.getIdAgendamento());
        ps.setString(2, Agendamento.getNomeServico());
        ps.setString(3, Agendamento.getDataAtendimento());
        ps.execute();

        ServicoDAO.AtualizaServico(Agendamento);
    }

    public static void DelecaoAgendamento(Agendamento Agendamento) throws SQLException {

        String Delecao = "delete from Agendamento where IdAgendamento = ?";
        PreparedStatement ps;

        ps = DbConector.CriaConexao().prepareStatement(Delecao);
        ps.setInt(1, Agendamento.getIdAgendamento());
        ps.execute();
    }

}
