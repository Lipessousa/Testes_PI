package conector;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class DbConector {

    public static final String url = "jdbc:mysql://localhost:3306/dbsalao?allowMultiQueries=true";
    public static final String usuario = "root";
    public static final String senha = "senhagenerica";

    public static Connection CriaConexao() throws SQLException {
        return DriverManager.getConnection(url, usuario, senha);
    }
    
}
