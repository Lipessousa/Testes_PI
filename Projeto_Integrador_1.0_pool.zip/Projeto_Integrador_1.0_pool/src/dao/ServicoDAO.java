package dao;

import conector.DbConector;
import entidades.Agendamento;
import entidades.Servico;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class ServicoDAO {
    
    public static List<Servico> Servico() throws SQLException{
        Servico s = new Servico();
        
        String select = "select * from Servico";
        PreparedStatement ps;
        List<Servico> listaServico = new ArrayList<>();
        
        ps = DbConector.CriaConexao().prepareStatement(select);
        ResultSet rs = ps.executeQuery();
        
        while (rs.next()){
            s = new Servico();
            
            s.setNomeServico(rs.getString("NomeServico"));
            s.setPrecoLocal(rs.getDouble("PrecoLocal"));
            s.setPrecoVisita(rs.getDouble("PrecoVisita"));
            
            listaServico.add(s);
        }
        
        return listaServico;
    }

    public static void Insercao(Servico servico) throws SQLException {

        String Insert = "INSERT INTO Servico(NomeServico, PrecoLocal, PrecoVisita) VALUES(?, ?, ?)";
        PreparedStatement ps;

        ps = DbConector.CriaConexao().prepareStatement(Insert);
        ps.setString(1, servico.getNomeServico());
        ps.setDouble(2, servico.getPrecoLocal());
        ps.setDouble(3, servico.getPrecoVisita());
        ps.execute();
    }
    
    public static List<Servico> Servicos() throws SQLException{
        Servico s = new Servico();
        
        String sql = "SELECT * FROM Servico";
        
        PreparedStatement ps;
        
        List<Servico>  listaS = new ArrayList<>();
        
        ps = DbConector.CriaConexao().prepareStatement(sql);
        
        ResultSet rs = ps.executeQuery();
        
        while (rs.next()) {            
            s = new Servico();
            
            s.setNomeServico(rs.getString(2));
            s.setPrecoLocal(rs.getDouble(3));
            s.setPrecoVisita(rs.getDouble(4));
            
            listaS.add(s);
        }
        
        return listaS;
    }
   
    public static void EditaServico(Servico servico) throws SQLException {
        String Atualizacao = "call EditaServico(?,?,?,?)";
        PreparedStatement ps;
        
        ps = DbConector.CriaConexao().prepareStatement(Atualizacao);
        ps.setString(1, servico.getNomeServico());
        ps.setString(2, servico.getAlteracao());
        ps.setDouble(3, servico.getPrecoLocal());
        ps.setDouble(4, servico.getPrecoVisita());
        ps.execute();
    }

    public static void Delecao(Servico servico) throws SQLException {

        String Delecao = "delete from Servico where NomeServico = ?";
        PreparedStatement ps;

        ps = DbConector.CriaConexao().prepareStatement(Delecao);
        ps.setString(1, servico.getNomeServico());
        ps.execute();
    }

    public static synchronized void SelectServico(Agendamento agendamento) throws SQLException {

        String consulta = "select * from Servico where lower(NomeServico) = lower(?)";
        ResultSet Resultado;
        PreparedStatement ps;
        Servico servico = new Servico();

        ps = DbConector.CriaConexao().prepareStatement(consulta);
        ps.setString(1, agendamento.getNomeServico());
        Resultado = ps.executeQuery();

        while (Resultado.next()) {
            agendamento.setIdServico(Resultado.getInt("IdServico"));
            servico.setPrecoVisita(Resultado.getDouble("PrecoVisita"));
            servico.setPrecoLocal(Resultado.getDouble("PrecoLocal"));
        }

        if (agendamento.tipoAtendimento.equals("Local")) {
            agendamento.setPrecoAtendimento(servico.precoLocal);
        } else {
            agendamento.setPrecoAtendimento(servico.precoVisita);
        }
        
    }

    public static synchronized void AtualizaServicoAgendamento(Agendamento agendamento) throws SQLException {

        String Id = "Select * from Servico where NomeServico = ?";
        ResultSet Resultado;
        PreparedStatement ps;
        Servico servico = new Servico();

        ps = DbConector.CriaConexao().prepareStatement(Id);
        ps.setString(1, agendamento.getNomeServico());
        Resultado = ps.executeQuery();

        while (Resultado.next()) {
            servico.setIdServico(Resultado.getInt("IdServico"));
            servico.setPrecoVisita(Resultado.getDouble("PrecoVisita"));
            servico.setPrecoLocal(Resultado.getDouble("PrecoLocal"));
        }

        agendamento.setIdServico(servico.getIdSercico());

        String UpdateId = "update Agendamento set IdServico = ? where lower(NomeCliente) = ?";

        ps = DbConector.CriaConexao().prepareStatement(UpdateId);
        ps.setInt(1, agendamento.getIdServico());
        ps.setString(2, agendamento.getNomeCliente());
        ps.execute();

        String LocalAtnedimento = "Select * from Cliente where lower(NomeCompleto) = lower(?)";

        ps = DbConector.CriaConexao().prepareStatement(LocalAtnedimento);
        ps.setString(1, agendamento.getNomeCliente());
        Resultado = ps.executeQuery();

        while (Resultado.next()) {
            agendamento.setTipoAtendimento(Resultado.getString("TipoAtendimento"));
        }

        if (agendamento.tipoAtendimento.equals("Local")) {
            agendamento.setPrecoAtendimento(servico.precoLocal);

            String UpdatePreco = "update Agendamento set PrecoAtendimento = ? where lower(NomeCliente) = ?";

            ps = DbConector.CriaConexao().prepareStatement(UpdatePreco);
            ps.setDouble(1, agendamento.getPrecoAtendimento());
            ps.setString(2, agendamento.getNomeCliente());
            ps.execute();

        } else {

            agendamento.setPrecoAtendimento(servico.precoVisita);

            String UpdatePreco = "update Agendamento set PrecoAtendimento = ? where lower(NomeCliente) = ?";

            ps = DbConector.CriaConexao().prepareStatement(UpdatePreco);
            ps.setDouble(1, agendamento.getPrecoAtendimento());
            ps.setString(2, agendamento.getNomeCliente());
            ps.execute();
        }

    }
    
    public static void AtualizaServico(Agendamento Agendamento) throws SQLException{
        Servico Servico = new Servico();
        
        String selection = "Select * from servico where NomeServico = ?";
        PreparedStatement ps;
        
        ps = DbConector.CriaConexao().prepareStatement(selection);
        ps.setString(1, Agendamento.getNomeServico());
        ResultSet resultado = ps.executeQuery();
        
        while (resultado.next()){
            Servico.setIdServico(resultado.getInt("IdServico"));
            Servico.setPrecoLocal(resultado.getDouble("PrecoLocal"));
            Servico.setPrecoVisita(resultado.getDouble("PrecoVisita"));
        }
        
        String Update = "update Agendamento set IdServico = ? where IdAgendamento = ?";
        
        ps = DbConector.CriaConexao().prepareStatement(Update);
        ps.setInt(1, Servico.getIdSercico());
        ps.setInt(2, Agendamento.getIdAgendamento());
        ps.execute();
        
        String selection2 = "Select * from agendamento where IdAgendamento = ?";
        
        ps = DbConector.CriaConexao().prepareStatement(selection2);
        ps.setInt(1, Agendamento.getIdAgendamento());
        resultado = ps.executeQuery();
        
        while (resultado.next()){
            Agendamento.setTipoAtendimento(resultado.getString("TipoAtendimento"));
        }
        
        if (Agendamento.getTipoAtendimento().equals("Local")){
            String update = "update Agendamento set PrecoAtendimento = ? where IdAgendamento = ?";
            
            ps = DbConector.CriaConexao().prepareStatement(update);
            ps.setDouble(1, Servico.getPrecoLocal());
            ps.setInt(2, Agendamento.getIdAgendamento());
            ps.execute();
            
        } else{
            String update = "update Agendamento set PrecoAtendimento = ? where IdAgendamento = ?";
            
            ps = DbConector.CriaConexao().prepareStatement(update);
            ps.setDouble(1, Servico.getPrecoVisita());
            ps.setInt(2, Agendamento.getIdAgendamento());
            ps.execute();
        }
    }

}
