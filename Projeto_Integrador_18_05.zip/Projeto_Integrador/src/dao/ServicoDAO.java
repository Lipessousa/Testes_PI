package dao;

import conector.DbConector;
import entidades.Agendamento;
import entidades.Servico;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class ServicoDAO {

    public static void Insercao(Servico servico) throws SQLException {

        String Insert = "INSERT INTO Servico(NomeServico, PrecoLocal, PrecoVisita) VALUES(?, ?, ?)";
        PreparedStatement PS;

        PS = DbConector.CriaConexao().prepareStatement(Insert);
        PS.setString(1, servico.getNomeServico());
        PS.setDouble(2, servico.getPrecoLocal());
        PS.setDouble(3, servico.getPrecoVisita());
        PS.execute();
    }
    
    public static List<Servico> Servicos() throws SQLException{
        Servico s = new Servico();
        
        String sql = "SELECT * FROM Servico";
        
        PreparedStatement ps;
        
        List<Servico>  listaS = new ArrayList<>();
        
        ps = DbConector.CriaConexao().prepareStatement(sql);
        
        ResultSet rs = ps.executeQuery();
        
        while (rs.next()) {            
            s = new Servico();
            
            s.setNomeServico(rs.getString(2));
            s.setPrecoLocal(rs.getDouble(3));
            s.setPrecoVisita(rs.getDouble(4));
            
            listaS.add(s);
        }
        
        return listaS;
    }
   

    public static void AtualizaNomeServico(Servico servico) throws SQLException {

        String Atualizacao = "update Servico set NomeServico = ? where lower(NomeServico) = Lower(?)";
        PreparedStatement PS;

        PS = DbConector.CriaConexao().prepareStatement(Atualizacao);
        PS.setString(1, servico.getAlteracao());
        PS.setString(2, servico.getNomeServico());
        PS.execute();
    }

    public static void AtualizaPrecoLocal(Servico servico) throws SQLException {

        String Atualizacao = "update Servico set NomeServico = ? where lower(NomeServico) = Lower(?)";
        PreparedStatement PS;

        PS = DbConector.CriaConexao().prepareStatement(Atualizacao);
        PS.setDouble(1, servico.getPrecoLocal());
        PS.setString(2, servico.getNomeServico());
        PS.execute();
    }

    public static void AtualizaPrecoVisita(Servico servico) throws SQLException {

        String Atualizacao = "update Servico set NomeServico = ? where lower(NomeServico) = Lower(?)";
        PreparedStatement PS;

        PS = DbConector.CriaConexao().prepareStatement(Atualizacao);
        PS.setDouble(1, servico.getPrecoVisita());
        PS.setString(2, servico.getNomeServico());
        PS.execute();
    }

    public static void Delecao(Servico servico) throws SQLException {

        String Delecao = "delete from Servico where NomeServico = ?";
        PreparedStatement PS;

        PS = DbConector.CriaConexao().prepareStatement(Delecao);
        PS.setString(1, servico.getNomeServico());
        PS.execute();
    }

    public static synchronized void SelectServico(Agendamento agendamento) throws SQLException {

        String consulta = "select * from Servico where lower(NomeServico) = lower(?)";
        ResultSet Resultado;
        PreparedStatement PS;
        Servico servico = new Servico();

        PS = DbConector.CriaConexao().prepareStatement(consulta);
        PS.setString(1, agendamento.getNomeServico());
        Resultado = PS.executeQuery();

        while (Resultado.next()) {
            agendamento.setIdServico(Resultado.getInt("IdServico"));
            servico.setPrecoVisita(Resultado.getDouble("PrecoVisita"));
            servico.setPrecoLocal(Resultado.getDouble("PrecoLocal"));
        }

        if (agendamento.tipoAtendimento.equals("Local")) {
            agendamento.setPrecoAtendimento(servico.precoLocal);
        } else {
            agendamento.setPrecoAtendimento(servico.precoVisita);
        }
        
    }

    public static synchronized void AtualizaServicoAgendamento(Agendamento agendamento) throws SQLException {

        String Id = "Select * from Servico where NomeServico = ?";
        ResultSet Resultado;
        PreparedStatement PS;
        Servico servico = new Servico();

        PS = DbConector.CriaConexao().prepareStatement(Id);
        PS.setString(1, agendamento.getNomeServico());
        Resultado = PS.executeQuery();

        while (Resultado.next()) {
            servico.setIdServico(Resultado.getInt("IdServico"));
            servico.setPrecoVisita(Resultado.getDouble("PrecoVisita"));
            servico.setPrecoLocal(Resultado.getDouble("PrecoLocal"));
        }

        agendamento.setIdServico(servico.getIdSercico());

        String UpdateId = "update Agendamento set IdServico = ? where lower(NomeCliente) = ?";

        PS = DbConector.CriaConexao().prepareStatement(UpdateId);
        PS.setInt(1, agendamento.getIdServico());
        PS.setString(2, agendamento.getNomeCliente());
        PS.execute();

        String LocalAtnedimento = "Select * from Cliente where lower(NomeCompleto) = lower(?)";

        PS = DbConector.CriaConexao().prepareStatement(LocalAtnedimento);
        PS.setString(1, agendamento.getNomeCliente());
        Resultado = PS.executeQuery();

        while (Resultado.next()) {
            agendamento.setTipoAtendimento(Resultado.getString("TipoAtendimento"));
        }

        if (agendamento.tipoAtendimento.equals("Local")) {
            agendamento.setPrecoAtendimento(servico.precoLocal);

            String UpdatePreco = "update Agendamento set PrecoAtendimento = ? where lower(NomeCliente) = ?";

            PS = DbConector.CriaConexao().prepareStatement(UpdatePreco);
            PS.setDouble(1, agendamento.getPrecoAtendimento());
            PS.setString(2, agendamento.getNomeCliente());
            PS.execute();

        } else {

            agendamento.setPrecoAtendimento(servico.precoVisita);

            String UpdatePreco = "update Agendamento set PrecoAtendimento = ? where lower(NomeCliente) = ?";

            PS = DbConector.CriaConexao().prepareStatement(UpdatePreco);
            PS.setDouble(1, agendamento.getPrecoAtendimento());
            PS.setString(2, agendamento.getNomeCliente());
            PS.execute();
        }

    }

}
