package dao;

import conector.DbConector;
import entidades.Agendamento;
import entidades.Cliente;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class ClienteDAO {

    public static void Insercao(Cliente cliente) throws SQLException {

        String Insert = "INSERT INTO Cliente(NomeCompleto, Telefone, TipoAtendimento) VALUES(?, ?, ?)";
        PreparedStatement ps;

        ps = DbConector.CriaConexao().prepareStatement(Insert);
        ps.setString(1, cliente.getNomeCompletoCliente());
        ps.setString(2, cliente.getTelefone());
        ps.setString(3, cliente.getTipoAtendimento());
        ps.execute();

    }

    //    Codigo para o insert via tela, cada VarCad � um dos text box a serem preenchidos
//    private void BtCadastroCliente(caralho) {
//        
//        String Nome = VarCadNome.GetText();
//        String Sobrenome = VarCadSobrenome.GetText();
//        String Telefone = VarCadTelefone.GetText();
//        String TipoAtendimento = VarCadTipoAtendimento.GetText();
//        
//        Cliente Cliente = new Cliente();
//        
//        Cliente.setNomeCliente(Nome);
//        Cliente.setSobrenomeCliente(Sobrenome);
//        Cliente.setTelefone(Telefone);
//        Cliente.setTipoAtendimento(TipoAtendimento);
//        
//        new ClienteDAO().Insercao(Cliente);
//        
//        
//    }
    
    public static List<Cliente> Clientes() throws SQLException{
        Cliente c = new Cliente();
        
        String sql = "SELECT * FROM Cliente";
        
        PreparedStatement ps;
        
        List<Cliente> listaC = new ArrayList<>();
        
        ps = DbConector.CriaConexao().prepareStatement(sql);
        
        ResultSet rs = ps.executeQuery();
        
        while (rs.next()) {            
            c = new Cliente();
            
            c.setNomeCompletoCliente(rs.getString(2));
            c.setTelefone(rs.getString(3));
            c.setTipoAtendimento(rs.getString(4));
            
            listaC.add(c);
        }
        
        return listaC;
    }

    
    
    public static void AtualizaTelefone(Cliente cliente) throws SQLException {

        String atualizacao = "update Cliente set Telefone = ? where lower(NC) = Lower(?)";
        PreparedStatement ps;

        ps = DbConector.CriaConexao().prepareStatement(atualizacao);
        ps.setString(1, cliente.getTelefone());
        ps.setString(2, cliente.getNomeCompletoCliente());
        ps.execute();

    }

    public static void AtualizaNome(Cliente cliente) throws SQLException {

        String atualizacao = "update Cliente set Nome = ? where lower(NomeCompleto) = Lower(?)";
        PreparedStatement ps;

        ps = DbConector.CriaConexao().prepareStatement(atualizacao);
        ps.setString(2, cliente.getNomeCompletoCliente());
        ps.execute();

    }

    public static void AtualizaSobrenome(Cliente cliente) throws SQLException {

        String atualizacao = "update Cliente set Sobrenome = ? where lower(NomeCompleto) = Lower(?)";
        PreparedStatement ps;

        ps = DbConector.CriaConexao().prepareStatement(atualizacao);
        ps.setString(2, cliente.getNomeCompletoCliente());
        ps.execute();
    }

    public static void Delecao(Cliente cliente) throws SQLException {

        String Delecao = "delete from Cliente where NomeCompleto = ?";
        PreparedStatement ps;

        ps = DbConector.CriaConexao().prepareStatement(Delecao);
        ps.setString(1, cliente.getNomeCompletoCliente());
        ps.execute();
    }

    public static synchronized void SelectCliente(Agendamento agendamento) throws SQLException {

        String consulta = "select IdCliente, TipoAtendimento from Cliente where lower(NomeCompleto) = lower(?)";
        ResultSet resultado;
        PreparedStatement ps;

        ps = DbConector.CriaConexao().prepareStatement(consulta);
        ps.setString(1, agendamento.getNomeCliente());
        resultado = ps.executeQuery();

        while (resultado.next()) {
            agendamento.setIdCliente(resultado.getInt("IdCliente"));
            agendamento.setTipoAtendimento(resultado.getString("TipoAtendimento"));
        }
        
    }

}
