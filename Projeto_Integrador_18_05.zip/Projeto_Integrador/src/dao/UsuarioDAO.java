package dao;

//Usuario
import entidades.Usuario;
//SQL
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;
import conector.DbConector;
import java.util.ArrayList;
//Swing
import javax.swing.JOptionPane;

public class UsuarioDAO {

    public static int usuarioAcesso;
    
    public static ArrayList<Usuario> listaU;

    public static void RegistroUsuario(Usuario usuario) throws SQLException {
        String read = "SELECT LoginUsuario FROM Usuario WHERE LoginUsuario = ?";
        String insert = "INSERT INTO Usuario(LoginUsuario, SenhaUsuario, Administrador) VALUES(?, ?, ?)";

        PreparedStatement ps;

        String usuarioNome = null;

        ps = DbConector.CriaConexao().prepareStatement(read);

        ps.setString(1, usuario.getLogin());

        ResultSet res = ps.executeQuery();

        while (res.next()) {
            usuarioNome = res.getString("LoginUsuario");
        }

        if (usuarioNome != null) {
            JOptionPane.showMessageDialog(null, "Usuário já existe");
        } else {
            ps = DbConector.CriaConexao().prepareStatement(insert);

            ps.setString(1, usuario.getLogin());
            ps.setString(2, usuario.getSenhaUsuario());
            ps.setInt(3, usuario.getAdministrador());

            ps.execute();
            JOptionPane.showMessageDialog(null, "Usu�rio criado com sucesso");
        }

    }
    
    
    public static ArrayList<Usuario> Usuarios(Usuario usuario) throws SQLException{
        String sql = "SELECT IdUsuario, LoginUsuario FROM Usuario WHERE Administrador = 0";
        
        PreparedStatement ps;

        listaU = new ArrayList<>();
        
        ps = DbConector.CriaConexao().prepareStatement(sql);
        
        ResultSet res = ps.executeQuery();

        while (res.next()) {
            int id = res.getInt("IdUsuario");
            usuario.setIdUsuario(id);
            
            String nome = res.getString("LoginUsuario");
            usuario.setLogin(nome);
            
            listaU.add(usuario);
        }
        
        System.out.println(listaU);
        
        return listaU;
    }

    public void AlteraSenhaUsuario(Usuario usuario) throws SQLException {
        String sql = "UPDATE Usuario SET SenhaUsuario = ? WHERE LoginUsuario = ?";

        PreparedStatement ps;

        ps = DbConector.CriaConexao().prepareStatement(sql);

        ps.setString(1, usuario.getSenhaUsuario());
        ps.setString(2, usuario.getLogin());

        ps.execute();
    }

    public void AlteraLoginUsuario(Usuario usuario) throws SQLException {
        String sql = "UPDATE Usuario SET LoginUsuario = ? WHERE LoginUsuario = ?";

        PreparedStatement ps;

        ps = DbConector.CriaConexao().prepareStatement(sql);

        ps.setString(1, usuario.getLogin());
        ps.setString(2, usuario.getLogin());

        ps.execute();
    }

    public void DeletaUsuario(Usuario usuario) throws SQLException {
        String sql = "DELETE FROM Usuario WHERE LoginUsuario = ?";

        PreparedStatement ps;

        ps = DbConector.CriaConexao().prepareStatement(sql);

        ps.setString(1, usuario.getLogin());

        ps.execute();

    }

    public static void LoginUsuario(Usuario usuario) throws SQLException {
        String sql = "SELECT * FROM Usuario WHERE LoginUsuario = ? and SenhaUsuario = ? ";

        String usuarioLogin = null;
        String usuarioSenha = null;
        int usuarioAdm;

        PreparedStatement ps = DbConector.CriaConexao().prepareStatement(sql);

        ps.setString(1, usuario.getLogin());
        ps.setString(2, usuario.getSenhaUsuario());

        ResultSet res = ps.executeQuery();

        while (res.next()) {
            usuarioLogin = res.getString("LoginUsuario");
            usuarioSenha = res.getString("SenhaUsuario");
            usuarioAdm = res.getInt("Administrador");
            usuarioAcesso = usuarioAdm;
        }

        if (usuarioLogin != null && usuarioSenha != null) {
            System.out.println("usuario: " + usuarioLogin);
        } else {
            System.out.println("Usuario ou senha incorretos");
            usuarioAcesso = 2;
        }

    }

}