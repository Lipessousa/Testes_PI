package dao;

import conector.DbConector;
import entidades.Agendamento;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class AgendamentoDAO {
    
     public static List<Agendamento> Historico() throws SQLException {

        PreparedStatement ps;
        ResultSet res;

        String select = "select * from VwAgendamentosInativos vw order by vw.DataAtendimento asc";

        ps = DbConector.CriaConexao().prepareStatement(select);
        res = ps.executeQuery();

        List<Agendamento> listaAgendamentoInativo = new ArrayList<>();
        
        
        while (res.next()) {
            Agendamento a = new Agendamento();
            a.setIdAgendamento(res.getInt("IdAgendamento"));
            a.setIdCliente(res.getInt("IdCliente"));
            a.setNomeCliente(res.getString("NomeCliente"));
            a.setIdServico(res.getInt("IdServico"));
            a.setNomeServico(res.getString("NomeServico"));
            a.setTipoAtendimento(res.getString("TipoAtendimento"));
            a.setDataAtendimento(res.getString("DataAtendimento"));
            a.setPrecoAtendimento(res.getDouble("PrecoAtendimento"));

            listaAgendamentoInativo.add(a);
        }

        return listaAgendamentoInativo;
    }

    public static List<Agendamento> Agendamento() throws SQLException {

        PreparedStatement PS;
        ResultSet Resultado;

        String select = "select * from VwAgendamentosAtivos order by DataAtendimento asc";

        PS = DbConector.CriaConexao().prepareStatement(select);
        Resultado = PS.executeQuery();

        List<Agendamento> listaAgendamento = new ArrayList<>();

        Agendamento a = new Agendamento();

        while (Resultado.next()) {
            Agendamento Agendamento = new Agendamento();
            Agendamento.setIdAgendamento(Resultado.getInt("IdAgendamento"));
            Agendamento.setIdCliente(Resultado.getInt("IdCliente"));
            Agendamento.setNomeCliente(Resultado.getString("NomeCliente"));
            Agendamento.setIdServico(Resultado.getInt("IdServico"));
            Agendamento.setNomeServico(Resultado.getString("NomeServico"));
            Agendamento.setTipoAtendimento(Resultado.getString("TipoAtendimento"));
            Agendamento.setDataAtendimento(Resultado.getString("DataAtendimento"));
            Agendamento.setPrecoAtendimento(Resultado.getDouble("PrecoAtendimento"));

            listaAgendamento.add(Agendamento);
        }

        return listaAgendamento;
    }

    public static void Insercao(Agendamento Agendamento) throws SQLException {

        String Insert = "insert into Agendamento(IdCliente, NomeCliente, IdServico, NomeServico, TipoAtendimento, DataAtendimento, PrecoAtendimento) VALUES(?, ?, ?, ?, ?, ?, ?)";
        PreparedStatement PS;

        ClienteDAO.SelectCliente(Agendamento);
        ServicoDAO.SelectServico(Agendamento);

        PS = DbConector.CriaConexao().prepareStatement(Insert);
        PS.setInt(1, Agendamento.getIdCliente());
        PS.setString(2, Agendamento.getNomeCliente());
        PS.setInt(3, Agendamento.getIdServico());
        PS.setString(4, Agendamento.getNomeServico());
        PS.setString(5, Agendamento.getTipoAtendimento());
        PS.setString(6, Agendamento.dataAtendimento);
        PS.setDouble(7, Agendamento.getPrecoAtendimento());
        PS.execute();

    }

    public static void AtualizaAgendamento(Agendamento Agendamento) throws SQLException {

        String atualizacao = "call EditaAgendamento(?,?,?)";
        PreparedStatement ps;

        ps = DbConector.CriaConexao().prepareStatement(atualizacao);
        ps.setInt(1, Agendamento.getIdAgendamento());
        ps.setString(2, Agendamento.getNomeServico());
        ps.setString(3, Agendamento.getDataAtendimento());
        ps.execute();

        ServicoDAO.AtualizaServico(Agendamento);
    }

    public static void DelecaoAgendamento(Agendamento Agendamento) throws SQLException {

        String Delecao = "delete from Agendamento where IdAgendamento = ?";
        PreparedStatement PS;

        PS = DbConector.CriaConexao().prepareStatement(Delecao);
        PS.setInt(1, Agendamento.getIdAgendamento());
        PS.execute();
    }

}
